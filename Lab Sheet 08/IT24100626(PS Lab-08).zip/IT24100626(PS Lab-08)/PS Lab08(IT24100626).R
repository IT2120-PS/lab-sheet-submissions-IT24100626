#setting the directorysetwd("C:\\Users\\HP\\Desktop\\IT24100626\\PS Lab 08")
setwd("C:\\Users\\HP\\Desktop\\IT24100626\\PS Lab 08")
data <- read.table("Data - Lab 8.txt", header = TRUE)
fix(data)
attach(data)
popmn <- mean(Nicotine)
popvar <- var(Nicotine)
samples <- c()
n<-c()
for(i in 1:30){
  s <- sample(Nicotine, 5, replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste('s', i))
}
colnames(samples) = n
s.means <- apply(samples, 2, mean)
s.vars <- apply(samples, 2, var)
samplemean <- mean(s.means)
samplesvars <- var(s.means)
truevar = popvar/5
print(popmn)
print(popvar)
print(samplemean)
print(samplesvars)
print(truevar)
setwd("C:\\Users\\HP\\Desktop\\IT24100626\\PS Lab 08")
#importing the data set
data <- read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)
#Question 01
popmean <- mean(Weight.kg.)
popmean
popsd<- sd(Weight.kg.)
popsd
#Question02
samples<- c()
n<-c()
for (j in 1:25) {
  s<- sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',j))
}
samples
n
colnames(samples)=n
samples
s.mean <- apply(samples,2,mean)
s.mean
s.sd<- apply(samples,2,sd)
s.sd
s.sd<-apply(samples,2,sd)
s.sd
#Question03
m.samplemean<-mean(s.mean)
m.samplemean
sd.samplemean<-sd(s.mean)
sd.samplemean
theoretical_sd_sm <- popsd/sqrt(6)
theoretical_sd_sm
sd.samplemean
